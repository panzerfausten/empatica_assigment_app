##Dummy class for logins
class UserManager:
	
	def __init__(self,user,password):
		self.user = user
		self.password = password
		
	def login:
		
class SystemUser:
	def __init__(self,id,user,password,url):
		self.id = id
		self.user= user
		self.password  = password
		self.url = url
class Users:
	s1 = SystemUser(1,"
	def __init__(self):
		
	def 
