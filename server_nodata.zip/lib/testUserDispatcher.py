from UserDispatcher import UserDispatcher

if __name__ ==  "__main__":
	u = UserDispatcher()
	print u.get(0)
