from Data import Data

d = Data(1)
d.getSessions()
print d.getDataFromSession("1447168483_40bba7","HR")
