curl "http://127.0.0.1:5000/api/users/1/data/sessions/1447248640_efbaa7/BVP" > data.json
